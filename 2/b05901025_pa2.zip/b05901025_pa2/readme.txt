compile: cd /src
         make

run: ./gr input_file output_file