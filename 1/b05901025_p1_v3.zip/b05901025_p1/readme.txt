compile method:  g++ -o fm Circuit.h Circuit.cpp utils.h main.cpp -std=c++11 -O3
run: ./fm [input_file] [output_file]

